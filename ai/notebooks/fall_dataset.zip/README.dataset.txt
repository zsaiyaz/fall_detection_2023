# Fall Detection > angry
https://universe.roboflow.com/vietnam-national-university-nizmq/fall-detection-fxpux

Provided by a Roboflow user
License: CC BY 4.0

